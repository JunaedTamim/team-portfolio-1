<?php
declare(strict_types=1);

/**
 * ============================================================
 * WebCraft Studios — Team Portfolio
 * ============================================================
 * 
 * This file bootstraps the application.
 * It supports two modes:
 *   1. DATABASE mode — reads from MySQL via TeamRepository
 *   2. DEMO mode     — uses hardcoded sample data (no DB needed)
 * 
 * Set USE_DATABASE to true once your DB is configured.
 */

const USE_DATABASE = false; // Toggle to true for MySQL

// ──────────── Autoload classes ────────────
spl_autoload_register(function (string $class) {
    $paths = [
        __DIR__ . "/classes/{$class}.php",
        __DIR__ . "/classes/Interfaces/{$class}.php",
        __DIR__ . "/config/{$class}.php",
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

// ──────────── Build the Team ────────────

$team = new Team(
    teamName:        'Meet Our Team',
    teamDescription: 'Talented individuals who turn ideas into exceptional digital products.'
);

if (USE_DATABASE) {
    // ── Mode 1: Load from database ──
    try {
        $db         = Database::getInstance()->getConnection();
        $repository = new TeamRepository($db);
        $members    = $repository->findAll();

        foreach ($members as $member) {
            $team->addMember($member);
        }
    } catch (Exception $e) {
        error_log("Database error: " . $e->getMessage());
        echo "<p style='color:red;text-align:center;padding:40px;'>
                  Could not load team data. Please check your database configuration.
              </p>";
        exit;
    }
} else {
    // ── Mode 2: Demo data (no database required) ──

    $team->addMember(new TeamMember(
        id:              1,
        firstName:       'Sarah',
        lastName:        'Mitchell',
        role:            'Lead Full-Stack Developer',
        bio:             'Architect of scalable web solutions with a passion for clean code and mentoring.',
        photoUrl:        'https://i.pravatar.cc/300?img=1',
        email:           'sarah@webcraft.io',
        skills:          ['PHP', 'Laravel', 'Vue.js', 'MySQL', 'Docker', 'AWS'],
        socialLinks:     [
            'github'   => 'https://github.com',
            'linkedin' => 'https://linkedin.com',
            'twitter'  => 'https://twitter.com',
        ],
        yearsExperience: 12,
        isLead:          true
    ));

    $team->addMember(new TeamMember(
        id:              2,
        firstName:       'Marcus',
        lastName:        'Chen',
        role:            'UI/UX Designer',
        bio:             'Creating intuitive and beautiful interfaces that users love. Design systems enthusiast.',
        photoUrl:        'https://i.pravatar.cc/300?img=3',
        email:           'marcus@webcraft.io',
        skills:          ['Figma', 'Adobe XD', 'CSS', 'Prototyping', 'User Research'],
        socialLinks:     [
            'dribbble' => 'https://dribbble.com',
            'linkedin' => 'https://linkedin.com',
        ],
        yearsExperience: 8,
        isLead:          false
    ));

    $team->addMember(new TeamMember(
        id:              3,
        firstName:       'Elena',
        lastName:        'Rodriguez',
        role:            'Frontend Developer',
        bio:             'Bringing designs to life with modern JavaScript frameworks and pixel-perfect code.',
        photoUrl:        'https://i.pravatar.cc/300?img=5',
        email:           'elena@webcraft.io',
        skills:          ['React', 'TypeScript', 'Tailwind CSS', 'Next.js', 'GraphQL'],
        socialLinks:     [
            'github'   => 'https://github.com',
            'linkedin' => 'https://linkedin.com',
            'twitter'  => 'https://twitter.com',
        ],
        yearsExperience: 6,
        isLead:          false
    ));

    $team->addMember(new TeamMember(
        id:              4,
        firstName:       'James',
        lastName:        "O'Brien",
        role:            'Backend Developer',
        bio:             'Building robust APIs and microservices. Database optimization specialist.',
        photoUrl:        'https://i.pravatar.cc/300?img=8',
        email:           'james@webcraft.io',
        skills:          ['PHP', 'Node.js', 'PostgreSQL', 'Redis', 'REST APIs'],
        socialLinks:     [
            'github'   => 'https://github.com',
            'linkedin' => 'https://linkedin.com',
        ],
        yearsExperience: 9,
        isLead:          false
    ));

    $team->addMember(new TeamMember(
        id:              5,
        firstName:       'Aisha',
        lastName:        'Patel',
        role:            'Project Manager',
        bio:             'Keeping projects on track. Certified Scrum Master with a developer background.',
        photoUrl:        'https://i.pravatar.cc/300?img=9',
        email:           'aisha@webcraft.io',
        skills:          ['Agile', 'Scrum', 'Jira', 'Client Relations', 'Risk Management'],
        socialLinks:     [
            'linkedin' => 'https://linkedin.com',
            'twitter'  => 'https://twitter.com',
        ],
        yearsExperience: 10,
        isLead:          true
    ));

    $team->addMember(new TeamMember(
        id:              6,
        firstName:       'David',
        lastName:        'Kim',
        role:            'DevOps Engineer',
        bio:             'Automating everything. CI/CD pipelines, cloud infrastructure, and monitoring at scale.',
        photoUrl:        'https://i.pravatar.cc/300?img=11',
        email:           'david@webcraft.io',
        skills:          ['AWS', 'Docker', 'Kubernetes', 'Terraform', 'GitHub Actions'],
        socialLinks:     [
            'github'   => 'https://github.com',
            'linkedin' => 'https://linkedin.com',
        ],
        yearsExperience: 7,
        isLead:          false
    ));
}

// ──────────── Sort & Render ────────────
$team->sortByExperience('DESC');

$renderer = new TeamRenderer($team, 'WebCraft Studios');
echo $renderer->renderPage();