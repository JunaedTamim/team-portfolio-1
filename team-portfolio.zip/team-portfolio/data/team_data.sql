-- Create database
CREATE DATABASE IF NOT EXISTS team_portfolio
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE team_portfolio;

-- Create table
CREATE TABLE IF NOT EXISTS team_members (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    first_name       VARCHAR(100)  NOT NULL,
    last_name        VARCHAR(100)  NOT NULL,
    role             VARCHAR(150)  NOT NULL,
    bio              TEXT          NULL,
    photo_url        VARCHAR(500)  NULL,
    email            VARCHAR(255)  NOT NULL,
    skills           JSON          NOT NULL DEFAULT '[]',
    social_links     JSON          NOT NULL DEFAULT '{}',
    years_experience INT           NOT NULL DEFAULT 0,
    is_lead          TINYINT(1)    NOT NULL DEFAULT 0,
    created_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Seed data
INSERT INTO team_members
    (first_name, last_name, role, bio, photo_url, email, skills, social_links, years_experience, is_lead)
VALUES
    ('Sarah', 'Mitchell',
     'Lead Full-Stack Developer',
     'Architect of scalable web solutions with a passion for clean code and mentoring junior developers.',
     'https://i.pravatar.cc/300?img=1',
     'sarah@webcraft.io',
     '["PHP", "Laravel", "Vue.js", "MySQL", "Docker", "AWS"]',
     '{"github": "https://github.com", "linkedin": "https://linkedin.com", "twitter": "https://twitter.com"}',
     12, 1),

    ('Marcus', 'Chen',
     'UI/UX Designer',
     'Creating intuitive and beautiful interfaces that users love. Design systems enthusiast.',
     'https://i.pravatar.cc/300?img=3',
     'marcus@webcraft.io',
     '["Figma", "Adobe XD", "CSS", "Prototyping", "User Research"]',
     '{"dribbble": "https://dribbble.com", "linkedin": "https://linkedin.com"}',
     8, 0),

    ('Elena', 'Rodriguez',
     'Frontend Developer',
     'Bringing designs to life with modern JavaScript frameworks and pixel-perfect implementations.',
     'https://i.pravatar.cc/300?img=5',
     'elena@webcraft.io',
     '["React", "TypeScript", "Tailwind CSS", "Next.js", "GraphQL"]',
     '{"github": "https://github.com", "linkedin": "https://linkedin.com", "twitter": "https://twitter.com"}',
     6, 0),

    ('James', 'O\'Brien',
     'Backend Developer',
     'Building robust APIs and microservices. Database optimization specialist.',
     'https://i.pravatar.cc/300?img=8',
     'james@webcraft.io',
     '["PHP", "Node.js", "PostgreSQL", "Redis", "REST APIs"]',
     '{"github": "https://github.com", "linkedin": "https://linkedin.com"}',
     9, 0),

    ('Aisha', 'Patel',
     'Project Manager',
     'Keeping projects on track and teams aligned. Certified Scrum Master with a developer background.',
     'https://i.pravatar.cc/300?img=9',
     'aisha@webcraft.io',
     '["Agile", "Scrum", "Jira", "Client Relations", "Risk Management"]',
     '{"linkedin": "https://linkedin.com", "twitter": "https://twitter.com"}',
     10, 1),

    ('David', 'Kim',
     'DevOps Engineer',
     'Automating everything. CI/CD pipelines, cloud infrastructure, and monitoring at scale.',
     'https://i.pravatar.cc/300?img=11',
     'david@webcraft.io',
     '["AWS", "Docker", "Kubernetes", "Terraform", "GitHub Actions", "Linux"]',
     '{"github": "https://github.com", "linkedin": "https://linkedin.com"}',
     7, 0);