<?php
declare(strict_types=1);

class TeamRepository implements RepositoryInterface
{
    private PDO $db;
    private string $table = 'team_members';

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Get all team members
     * @return TeamMember[]
     */
    public function findAll(): array
    {
        $stmt = $this->db->query("SELECT * FROM {$this->table} ORDER BY is_lead DESC, id ASC");
        $rows = $stmt->fetchAll();

        return array_map(fn(array $row) => TeamMember::fromArray($row), $rows);
    }

    /**
     * Find a single member by ID
     */
    public function findById(int $id): ?TeamMember
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();

        return $row ? TeamMember::fromArray($row) : null;
    }

    /**
     * Find members by role
     * @return TeamMember[]
     */
    public function findByRole(string $role): array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE role LIKE :role");
        $stmt->execute([':role' => "%{$role}%"]);
        $rows = $stmt->fetchAll();

        return array_map(fn(array $row) => TeamMember::fromArray($row), $rows);
    }

    /**
     * Save (insert or update) a team member
     */
    public function save(object $entity): bool
    {
        if (!$entity instanceof TeamMember) {
            throw new InvalidArgumentException("Expected TeamMember instance");
        }

        $data = $entity->toArray();
        // Encode arrays to JSON for DB storage
        $data['skills']       = json_encode($data['skills']);
        $data['social_links'] = json_encode($data['social_links']);
        $data['is_lead']      = (int) $data['is_lead'];

        if ($entity->getId() > 0 && $this->findById($entity->getId())) {
            return $this->update($data);
        }
        return $this->insert($data);
    }

    /**
     * Delete a team member by ID
     */
    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    // ──────────────────────────── PRIVATE HELPERS ────────────────────

    private function insert(array $data): bool
    {
        unset($data['id']); // auto-increment
        $columns      = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_map(fn($k) => ":{$k}", array_keys($data)));

        $sql  = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
        $stmt = $this->db->prepare($sql);

        return $stmt->execute($data);
    }

    private function update(array $data): bool
    {
        $id = $data['id'];
        unset($data['id']);

        $setClause = implode(', ', array_map(fn($k) => "{$k} = :{$k}", array_keys($data)));
        $data['id'] = $id;

        $sql  = "UPDATE {$this->table} SET {$setClause} WHERE id = :id";
        $stmt = $this->db->prepare($sql);

        return $stmt->execute($data);
    }
}