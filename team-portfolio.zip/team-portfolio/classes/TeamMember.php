<?php
declare(strict_types=1);

class TeamMember implements RenderableInterface
{
    private int    $id;
    private string $firstName;
    private string $lastName;
    private string $role;
    private string $bio;
    private string $photoUrl;
    private string $email;
    private array  $skills;
    private array  $socialLinks;
    private int    $yearsExperience;
    private bool   $isLead;

    /**
     * Constructor with named parameters style
     */
    public function __construct(
        int    $id              = 0,
        string $firstName       = '',
        string $lastName        = '',
        string $role            = '',
        string $bio             = '',
        string $photoUrl        = '',
        string $email           = '',
        array  $skills          = [],
        array  $socialLinks     = [],
        int    $yearsExperience = 0,
        bool   $isLead          = false
    ) {
        $this->id              = $id;
        $this->firstName       = $firstName;
        $this->lastName        = $lastName;
        $this->role            = $role;
        $this->bio             = $bio;
        $this->photoUrl        = $photoUrl;
        $this->email           = $email;
        $this->skills          = $skills;
        $this->socialLinks     = $socialLinks;
        $this->yearsExperience = $yearsExperience;
        $this->isLead          = $isLead;
    }

    // ──────────────────────────── GETTERS ────────────────────────────

    public function getId(): int             { return $this->id; }
    public function getFirstName(): string   { return $this->firstName; }
    public function getLastName(): string    { return $this->lastName; }
    public function getRole(): string        { return $this->role; }
    public function getBio(): string         { return $this->bio; }
    public function getPhotoUrl(): string    { return $this->photoUrl; }
    public function getEmail(): string       { return $this->email; }
    public function getSkills(): array       { return $this->skills; }
    public function getSocialLinks(): array  { return $this->socialLinks; }
    public function getYearsExperience(): int{ return $this->yearsExperience; }
    public function isLead(): bool           { return $this->isLead; }

    /**
     * Get full name
     */
    public function getFullName(): string
    {
        return trim("{$this->firstName} {$this->lastName}");
    }

    /**
     * Get initials for avatar fallback
     */
    public function getInitials(): string
    {
        $first = !empty($this->firstName) ? mb_substr($this->firstName, 0, 1) : '';
        $last  = !empty($this->lastName)  ? mb_substr($this->lastName, 0, 1)  : '';
        return strtoupper($first . $last);
    }

    // ──────────────────────────── SETTERS ────────────────────────────

    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function setFirstName(string $firstName): self
    {
        $this->firstName = $firstName;
        return $this;
    }

    public function setLastName(string $lastName): self
    {
        $this->lastName = $lastName;
        return $this;
    }

    public function setRole(string $role): self
    {
        $this->role = $role;
        return $this;
    }

    public function setBio(string $bio): self
    {
        $this->bio = $bio;
        return $this;
    }

    public function setPhotoUrl(string $photoUrl): self
    {
        $this->photoUrl = $photoUrl;
        return $this;
    }

    public function setEmail(string $email): self
    {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException("Invalid email: {$email}");
        }
        $this->email = $email;
        return $this;
    }

    public function setSkills(array $skills): self
    {
        $this->skills = array_map('trim', $skills);
        return $this;
    }

    public function addSkill(string $skill): self
    {
        $this->skills[] = trim($skill);
        return $this;
    }

    public function setSocialLinks(array $links): self
    {
        $this->socialLinks = $links;
        return $this;
    }

    public function addSocialLink(string $platform, string $url): self
    {
        $this->socialLinks[$platform] = $url;
        return $this;
    }

    public function setYearsExperience(int $years): self
    {
        if ($years < 0) {
            throw new InvalidArgumentException("Years of experience cannot be negative");
        }
        $this->yearsExperience = $years;
        return $this;
    }

    public function setIsLead(bool $isLead): self
    {
        $this->isLead = $isLead;
        return $this;
    }

    // ──────────────────────────── RENDER ────────────────────────────

    /**
     * Render a single team member card
     */
    public function render(): string
    {
        $name        = htmlspecialchars($this->getFullName());
        $role        = htmlspecialchars($this->role);
        $bio         = htmlspecialchars($this->bio);
        $email       = htmlspecialchars($this->email);
        $photo       = htmlspecialchars($this->photoUrl);
        $initials    = htmlspecialchars($this->getInitials());
        $experience  = $this->yearsExperience;
        $leadBadge   = $this->isLead ? '<span class="badge badge-lead">Team Lead</span>' : '';

        // Build skills HTML
        $skillsHtml = '';
        foreach ($this->skills as $skill) {
            $skillsHtml .= '<span class="skill-tag">' . htmlspecialchars($skill) . '</span>';
        }

        // Build social links HTML
        $socialHtml = '';
        $socialIcons = [
            'github'   => '&#xf09b;',
            'linkedin' => '&#xf0e1;',
            'twitter'  => '&#xf099;',
            'website'  => '&#xf0ac;',
            'dribbble' => '&#xf17d;',
        ];
        foreach ($this->socialLinks as $platform => $url) {
            $safeUrl  = htmlspecialchars($url);
            $safeName = htmlspecialchars(ucfirst($platform));
            $socialHtml .= "<a href=\"{$safeUrl}\" target=\"_blank\" 
                               class=\"social-link social-{$platform}\" 
                               title=\"{$safeName}\">{$safeName}</a>";
        }

        // Photo or initials fallback
        $photoHtml = !empty($this->photoUrl)
            ? "<img src=\"{$photo}\" alt=\"{$name}\" class=\"member-photo\">"
            : "<div class=\"member-initials\">{$initials}</div>";

        return <<<HTML
        <div class="team-card" data-role="{$role}">
            <div class="card-header">
                <div class="photo-wrapper">
                    {$photoHtml}
                    <div class="status-dot online"></div>
                </div>
                {$leadBadge}
            </div>
            <div class="card-body">
                <h3 class="member-name">{$name}</h3>
                <p class="member-role">{$role}</p>
                <p class="member-bio">{$bio}</p>
                <div class="member-experience">
                    <span class="exp-number">{$experience}</span>
                    <span class="exp-label">Years Experience</span>
                </div>
                <div class="member-skills">{$skillsHtml}</div>
            </div>
            <div class="card-footer">
                <div class="social-links">{$socialHtml}</div>
                <a href="mailto:{$email}" class="contact-btn">Contact</a>
            </div>
        </div>
        HTML;
    }

    // ──────────────────────────── SERIALIZATION ────────────────────

    /**
     * Convert to array
     */
    public function toArray(): array
    {
        return [
            'id'               => $this->id,
            'first_name'       => $this->firstName,
            'last_name'        => $this->lastName,
            'role'             => $this->role,
            'bio'              => $this->bio,
            'photo_url'        => $this->photoUrl,
            'email'            => $this->email,
            'skills'           => $this->skills,
            'social_links'     => $this->socialLinks,
            'years_experience' => $this->yearsExperience,
            'is_lead'          => $this->isLead,
        ];
    }

    /**
     * Create from array (factory method)
     */
    public static function fromArray(array $data): self
    {
        return new self(
            id:              (int)   ($data['id'] ?? 0),
            firstName:       (string)($data['first_name'] ?? ''),
            lastName:        (string)($data['last_name'] ?? ''),
            role:            (string)($data['role'] ?? ''),
            bio:             (string)($data['bio'] ?? ''),
            photoUrl:        (string)($data['photo_url'] ?? ''),
            email:           (string)($data['email'] ?? ''),
            skills:          is_array($data['skills'] ?? null)
                                ? $data['skills']
                                : json_decode($data['skills'] ?? '[]', true) ?? [],
            socialLinks:     is_array($data['social_links'] ?? null)
                                ? $data['social_links']
                                : json_decode($data['social_links'] ?? '{}', true) ?? [],
            yearsExperience: (int)   ($data['years_experience'] ?? 0),
            isLead:          (bool)  ($data['is_lead'] ?? false),
        );
    }
}