<?php
declare(strict_types=1);

interface RepositoryInterface
{
    public function findAll(): array;
    public function findById(int $id): ?object;
    public function findByRole(string $role): array;
    public function save(object $entity): bool;
    public function delete(int $id): bool;
}