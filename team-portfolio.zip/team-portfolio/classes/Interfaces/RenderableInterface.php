<?php
declare(strict_types=1);

interface RenderableInterface
{
    /**
     * Render the object as HTML
     */
    public function render(): string;
}