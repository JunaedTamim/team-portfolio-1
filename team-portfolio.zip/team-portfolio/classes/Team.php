<?php
declare(strict_types=1);

class Team implements RenderableInterface, Countable, IteratorAggregate
{
    /** @var TeamMember[] */
    private array  $members  = [];
    private string $teamName;
    private string $teamDescription;

    public function __construct(string $teamName = 'Our Team', string $teamDescription = '')
    {
        $this->teamName        = $teamName;
        $this->teamDescription = $teamDescription;
    }

    // ──────────────────────────── MEMBER MANAGEMENT ────────────────

    /**
     * Add a member to the team
     */
    public function addMember(TeamMember $member): self
    {
        $this->members[$member->getId()] = $member;
        return $this;
    }

    /**
     * Remove a member by ID
     */
    public function removeMember(int $id): self
    {
        unset($this->members[$id]);
        return $this;
    }

    /**
     * Get a member by ID
     */
    public function getMember(int $id): ?TeamMember
    {
        return $this->members[$id] ?? null;
    }

    /**
     * Get all members
     * @return TeamMember[]
     */
    public function getMembers(): array
    {
        return $this->members;
    }

    /**
     * Check if a member exists
     */
    public function hasMember(int $id): bool
    {
        return isset($this->members[$id]);
    }

    // ──────────────────────────── FILTERING & SORTING ────────────────

    /**
     * Filter members by role
     * @return TeamMember[]
     */
    public function filterByRole(string $role): array
    {
        return array_filter($this->members, function (TeamMember $m) use ($role) {
            return stripos($m->getRole(), $role) !== false;
        });
    }

    /**
     * Get only team leads
     * @return TeamMember[]
     */
    public function getLeads(): array
    {
        return array_filter($this->members, fn(TeamMember $m) => $m->isLead());
    }

    /**
     * Filter members who have a specific skill
     * @return TeamMember[]
     */
    public function filterBySkill(string $skill): array
    {
        return array_filter($this->members, function (TeamMember $m) use ($skill) {
            return in_array(strtolower($skill), array_map('strtolower', $m->getSkills()));
        });
    }

    /**
     * Sort members by experience (descending)
     */
    public function sortByExperience(string $direction = 'DESC'): self
    {
        uasort($this->members, function (TeamMember $a, TeamMember $b) use ($direction) {
            $diff = $b->getYearsExperience() - $a->getYearsExperience();
            return $direction === 'ASC' ? -$diff : $diff;
        });
        return $this;
    }

    /**
     * Sort members by name (alphabetical)
     */
    public function sortByName(string $direction = 'ASC'): self
    {
        uasort($this->members, function (TeamMember $a, TeamMember $b) use ($direction) {
            $diff = strcmp($a->getFullName(), $b->getFullName());
            return $direction === 'DESC' ? -$diff : $diff;
        });
        return $this;
    }

    /**
     * Get all unique roles in the team
     */
    public function getUniqueRoles(): array
    {
        $roles = array_map(fn(TeamMember $m) => $m->getRole(), $this->members);
        return array_unique($roles);
    }

    /**
     * Get all unique skills across the team
     */
    public function getAllSkills(): array
    {
        $skills = [];
        foreach ($this->members as $member) {
            $skills = array_merge($skills, $member->getSkills());
        }
        return array_unique($skills);
    }

    /**
     * Get team statistics
     */
    public function getStats(): array
    {
        $totalExp = array_sum(
            array_map(fn(TeamMember $m) => $m->getYearsExperience(), $this->members)
        );

        return [
            'total_members'     => $this->count(),
            'total_experience'  => $totalExp,
            'avg_experience'    => $this->count() > 0
                                    ? round($totalExp / $this->count(), 1) : 0,
            'unique_roles'      => count($this->getUniqueRoles()),
            'total_skills'      => count($this->getAllSkills()),
            'team_leads'        => count($this->getLeads()),
        ];
    }

    // ──────────────────────────── INTERFACES ─────────────────────────

    public function count(): int
    {
        return count($this->members);
    }

    public function getIterator(): ArrayIterator
    {
        return new ArrayIterator($this->members);
    }

    // ──────────────────────────── RENDER ─────────────────────────────

    /**
     * Render the full team section
     */
    public function render(): string
    {
        $teamName = htmlspecialchars($this->teamName);
        $teamDesc = htmlspecialchars($this->teamDescription);
        $stats    = $this->getStats();

        // Stats bar
        $statsHtml = <<<HTML
        <div class="team-stats">
            <div class="stat-item">
                <span class="stat-number">{$stats['total_members']}</span>
                <span class="stat-label">Team Members</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">{$stats['total_experience']}</span>
                <span class="stat-label">Years Combined Experience</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">{$stats['total_skills']}</span>
                <span class="stat-label">Unique Skills</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">{$stats['unique_roles']}</span>
                <span class="stat-label">Specializations</span>
            </div>
        </div>
        HTML;

        // Role filter buttons
        $roles     = $this->getUniqueRoles();
        $filterHtml = '<div class="filter-bar"><button class="filter-btn active" data-filter="all">All</button>';
        foreach ($roles as $role) {
            $safeRole    = htmlspecialchars($role);
            $filterHtml .= "<button class=\"filter-btn\" data-filter=\"{$safeRole}\">{$safeRole}</button>";
        }
        $filterHtml .= '</div>';

        // Member cards
        $cardsHtml = '';
        foreach ($this->members as $member) {
            $cardsHtml .= $member->render();
        }

        return <<<HTML
        <section class="team-section">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title">{$teamName}</h2>
                    <p class="section-description">{$teamDesc}</p>
                </div>
                {$statsHtml}
                {$filterHtml}
                <div class="team-grid">
                    {$cardsHtml}
                </div>
            </div>
        </section>
        HTML;
    }
}