<?php
declare(strict_types=1);

class TeamRenderer
{
    private Team $team;
    private string $companyName;

    public function __construct(Team $team, string $companyName = 'WebCraft Studios')
    {
        $this->team        = $team;
        $this->companyName = $companyName;
    }

    /**
     * Render the full HTML page
     */
    public function renderPage(): string
    {
        $company   = htmlspecialchars($this->companyName);
        $teamHtml  = $this->team->render();
        $year      = date('Y');
        $cssPath   = 'assets/css/style.css';

        return <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>{$company} — Meet Our Team</title>
            <link rel="stylesheet" href="{$cssPath}">
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" 
                  rel="stylesheet">
        </head>
        <body>

            <!-- NAVIGATION -->
            <nav class="navbar">
                <div class="container">
                    <a href="#" class="logo">
                        <span class="logo-icon">&#9674;</span> {$company}
                    </a>
                    <ul class="nav-links">
                        <li><a href="#" class="active">Team</a></li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Services</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
            </nav>

            <!-- HERO -->
            <header class="hero">
                <div class="container">
                    <h1 class="hero-title">The People Behind<br>
                        <span class="highlight">Your Digital Vision</span>
                    </h1>
                    <p class="hero-subtitle">
                        We're a passionate team of designers, developers, and strategists 
                        who craft exceptional digital experiences.
                    </p>
                </div>
            </header>

            <!-- TEAM SECTION -->
            {$teamHtml}

            <!-- FOOTER -->
            <footer class="footer">
                <div class="container">
                    <p>&copy; {$year} {$company}. All rights reserved.</p>
                    <p>Building the web, one pixel at a time.</p>
                </div>
            </footer>

            <!-- FILTER SCRIPT -->
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const buttons = document.querySelectorAll('.filter-btn');
                    const cards   = document.querySelectorAll('.team-card');

                    buttons.forEach(btn => {
                        btn.addEventListener('click', function() {
                            buttons.forEach(b => b.classList.remove('active'));
                            this.classList.add('active');

                            const filter = this.getAttribute('data-filter');

                            cards.forEach(card => {
                                if (filter === 'all' || card.getAttribute('data-role') === filter) {
                                    card.style.display = '';
                                    card.style.animation = 'fadeInUp 0.5s ease forwards';
                                } else {
                                    card.style.display = 'none';
                                }
                            });
                        });
                    });
                });
            </script>

        </body>
        </html>
        HTML;
    }
}